package constant;

public class ConstantValue {
public final static int STUBOOKNUM=6;
public final static int TEABOOKNUM=8;
public final static int STUBORROWDAYS=30;
public final static int TEABORROWDAYS=60;
}
