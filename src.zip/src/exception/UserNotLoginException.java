package exception;

public class UserNotLoginException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotLoginException(){
		System.out.println("登陆了吗你就借 出门左转登陆去");
	}
}
