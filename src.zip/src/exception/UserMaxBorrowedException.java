package exception;

public class UserMaxBorrowedException extends Exception {

}
