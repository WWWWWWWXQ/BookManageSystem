package exception;

public class UserOweFeeException extends Exception {
}
