package book;

public class TestTec {
    public static void main(String[] args) {
        Test test = new Test();
        test.display();
        test.addBook();
        test.display();
    }
}
